<?php if(ux_enable_page_template()){ ?>
    <div class="gallery-navi-post">
        <div class="gallery-navi-prev"><a href="#"><span class="fa fa-angle-left"></span></a></div>
        <div class="gallery-navi-next"><a href="#"><span class="fa fa-angle-right"></span></a></div>
    </div>
<?php } ?>