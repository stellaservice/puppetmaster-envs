<?php if(get_the_content()){ ?>
    <div class="entry"><?php the_content(); wp_link_pages(); ?></div><!--End entry-->
<?php } ?>