<?php
/*
============================================================================
	*
	* require functions pagebuilder 
	*
============================================================================	
*/
require_once locate_template('/functions/pagebuilder/pagebuilder-admin.php');

/*
============================================================================
	*
	* require functions theme 
	*
============================================================================	
*/
require_once locate_template('/functions/theme/theme-admin.php');

/*
============================================================================
	*
	* require class 
	*
============================================================================	
*/
require_once locate_template('/functions/class/class-admin.php');

/*
============================================================================
	*
	* require interface 
	*
============================================================================	
*/
require_once locate_template('/functions/interface/interface-admin.php');

?>