</div><!--End .container sidebar-layout-->
<?php ux_interface_footer_widget(); ?>
                    
</div><!--End content_wrap_outer-->